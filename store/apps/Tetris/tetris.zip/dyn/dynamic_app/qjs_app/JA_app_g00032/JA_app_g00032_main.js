import * as lv from "lv"
import * as lv_enums from "/support_script/qjs/lv_enums.js"
import {app} from "lvapp"
import {btn} from "/support_script/qjs/btn.js"
import {cont} from "/support_script/qjs/cont.js"
import {img} from "/support_script/qjs/img.js"
import {label} from "/support_script/qjs/label.js"
import {app_get_str} from "./JA_app_g00032_language.js"
"use math"

/*======================================================================
  Tetris — modernized for HK 10 Pro Max+
  - Clean, modular structure (no stuffed code)
  - Fixed collision & line-clear bugs
  - Smooth fall / move / rotate animations
  - Crown key support for piece movement
  - Next-piece preview, level speed-up, score, high-score
  - Small footprint, optimized rendering
======================================================================*/

// ---- constants --------------------------------------------------------
const GRID_W  = 10
const GRID_H  = 12
const BLOCK   = 41
const OFF_X   = 0
const OFF_Y   = 1

const SCREEN_TITLE   = 0
const SCREEN_PLAYING = 1
const SCREEN_GAMEOVER= 2

const DIR_NONE  = 0
const DIR_LEFT  = 4
const DIR_RIGHT = 8
const DIR_UP    = 1 // rotate

const COLORS = ["tetris_red.bin", "tetris_green.bin", "tetris_yellow.bin"]

const SCORE_1LINE = 1
const SCORE_2LINE = 3
const SCORE_3LINE = 6
const SCORE_4LINE = 10

// Tetromino shapes: [type][rotation][cell] = [dx, dy]
// 4 cells per piece, rotations 1..4
const SHAPES = {
  0: { // L
    1: [[0,0],[0,-1],[0,1],[1,1]],
    2: [[0,0],[-1,0],[1,0],[-1,1]],
    3: [[0,0],[0,-1],[0,1],[-1,-1]],
    4: [[0,0],[-1,0],[1,0],[1,-1]],
  },
  1: { // J
    1: [[0,0],[0,-1],[0,1],[-1,1]],
    2: [[0,0],[-1,0],[1,0],[-1,-1]],
    3: [[0,0],[0,-1],[0,1],[1,-1]],
    4: [[0,0],[-1,0],[1,0],[1,1]],
  },
  2: { // T
    1: [[0,0],[-1,0],[1,0],[0,-1]],
    2: [[0,0],[0,-1],[0,1],[1,0]],
    3: [[0,0],[-1,0],[1,0],[0,1]],
    4: [[0,0],[0,-1],[0,1],[-1,0]],
  },
  3: { // I
    1: [[0,0],[0,-1],[0,1],[0,2]],
    2: [[0,0],[-1,0],[1,0],[2,0]],
    3: [[0,0],[0,-1],[0,1],[0,2]],
    4: [[0,0],[-1,0],[1,0],[2,0]],
  },
  4: { // S
    1: [[0,0],[-1,0],[0,-1],[1,-1]],
    2: [[0,0],[-1,0],[0,1],[-1,-1]],
    3: [[0,0],[-1,0],[0,-1],[1,-1]],
    4: [[0,0],[-1,0],[0,1],[-1,-1]],
  },
  5: { // Z
    1: [[0,0],[1,0],[0,-1],[-1,-1]],
    2: [[0,0],[-1,0],[0,-1],[-1,1]],
    3: [[0,0],[1,0],[0,-1],[-1,-1]],
    4: [[0,0],[-1,0],[0,-1],[-1,1]],
  },
  6: { // O
    1: [[0,0],[1,0],[0,-1],[1,-1]],
    2: [[0,0],[1,0],[0,-1],[1,-1]],
    3: [[0,0],[1,0],[0,-1],[1,-1]],
    4: [[0,0],[1,0],[0,-1],[1,-1]],
  },
}

class JA_app_g00032 extends app{
    constructor() {
        super()
        this.LV_HOR_RES_MAX = lv.get_hor_max()
        this.LV_VER_RES_MAX = lv.get_ver_max()

        this.show_time = true
        this.game_score = 0
        this.high_score = 0
        this.level = 1
        this.lines = 0
        this.screen = SCREEN_TITLE
        this.gameStartFlag = false

        this.tetris_w = BLOCK
        this.tetris_h = BLOCK
        this.tetris_start_x = OFF_X
        this.tetris_start_y = OFF_Y

        this.tetris_table = COLORS

        // piece state
        this.tetrisShapeType = 0
        this.pieceX = 4
        this.pieceY = -1
        this.pieceRot = 1
        this.pieceColor = 0
        this.box_new = 0
        this.tetris_list = undefined
        this.tetris_total_list = []
        this.tetris_pos = undefined
        this.nextShapeType = 0
        this.nextColor = 0

        // grid
        this.tetrisMap = []
        this._initMap()

        // animation state
        this.anim = {
            active: false,
            type: "none",      // "fall", "move", "rotate", "clear", "gameover"
            fromX: 0, fromY: 0,
            toX: 0,   toY: 0,
            progress: 0,       // 0..1
            duration: 0,       // frames
            frame: 0,
            pieceCells: [],    // [{x,y}]
            clearRows: [],     // row indexes being cleared
        }

        // input
        this.tetris_gesture = 0
        this.last_min = -1
        this.dropTimer = 0
        this.dropInterval = 30 // frames per cell drop at level 1

        // UI refs
        this.obj_bg = undefined
        this.obj_sroce = undefined
        this.txt_title = undefined
        this.txt_time_dot = undefined
        this.txt_time_hour = undefined
        this.txt_time_min = undefined
        this.icon = undefined
        this.score_cont = undefined
        this.img_score = undefined
        this.txt_score = undefined
        this.img_start = undefined
        this.result_bigbtn = undefined
        this.result_btn = undefined
        this.result_cont = undefined
        this.img_result = undefined
        this.txt_result = undefined
        this.gameover = undefined
        this.gameagain = undefined
        this.gameback = undefined
        this.next_cont = undefined
        this.next_label = undefined
    }

    _initMap() {
        this.tetrisMap = []
        for (var i = 0; i < GRID_W; i++) {
            this.tetrisMap[i] = []
            for (var j = -3; j < GRID_H; j++) {
                this.tetrisMap[i][j] = 0
            }
        }
    }

    _cellShape() {
        return SHAPES[this.tetrisShapeType][this.pieceRot]
    }

    _canMove(dx, dy, rot) {
        var shape = (rot !== undefined) ? SHAPES[this.tetrisShapeType][rot] : this._cellShape()
        for (var i = 0; i < 4; i++) {
            var x = this.pieceX + dx + shape[i][0]
            var y = this.pieceY + dy + shape[i][1]
            if (x < 0 || x >= GRID_W || y >= GRID_H) return 0
            if (y >= 0 && this.tetrisMap[x][y] == 1) return 0
        }
        return 1
    }

    _lockPiece() {
        var shape = this._cellShape()
        for (var i = 0; i < 4; i++) {
            var x = this.pieceX + shape[i][0]
            var y = this.pieceY + shape[i][1]
            if (x >= 0 && x < GRID_W && y >= 0 && y < GRID_H) {
                this.tetrisMap[x][y] = 1
            }
        }
        this._storePieces()
        this.box_new = 0
        this.tetris_list = undefined
        // game over check: if any locked cell is above visible area
        for (var i = 0; i < 4; i++) {
            var y = this.pieceY + this._cellShape()[i][1]
            if (y < 0) {
                this.screen = SCREEN_GAMEOVER
                return
            }
        }
    }

    _storePieces() {
        for (var i = 0; i < this.tetris_total_list.length; i++) {
            var e = this.tetris_total_list[i]
            if (e && e.obj) e.obj.delete()
        }
        this.tetris_total_list = []
        var shape = this._cellShape()
        for (var i = 0; i < 4; i++) {
            var x = this.pieceX + shape[i][0]
            var y = this.pieceY + shape[i][1]
            if (x < 0 || x >= GRID_W || y < 0 || y >= GRID_H) continue
            var obj = new img(this.root())
            obj.set_src(this.path() + this.tetris_table[this.pieceColor])
            obj.set_pos(x * BLOCK + OFF_X, y * BLOCK + OFF_Y)
            this.tetris_total_list.push({obj: obj, x: x, y: y})
        }
    }

    _clearLines() {
        var rows = []
        for (var y = 0; y < GRID_H; y++) {
            var full = 1
            for (var x = 0; x < GRID_W; x++) {
                if (this.tetrisMap[x][y] != 1) { full = 0; break }
            }
            if (full) rows.push(y)
        }
        if (rows.length === 0) return 0

        // remove locked objects in cleared rows
        for (var r = 0; r < rows.length; r++) {
            var ry = rows[r]
            for (var i = this.tetris_total_list.length - 1; i >= 0; i--) {
                var e = this.tetris_total_list[i]
                if (e && e.y == ry) {
                    if (e.obj) e.obj.delete()
                    this.tetris_total_list.splice(i, 1)
                }
            }
            for (var x = 0; x < GRID_W; x++) this.tetrisMap[x][ry] = 0
        }

        // shift rows above down
        rows.sort(function(a,b){return b-a})
        for (var r = 0; r < rows.length; r++) {
            var ry = rows[r]
            for (var y = ry - 1; y >= 0; y--) {
                for (var x = 0; x < GRID_W; x++) {
                    if (this.tetrisMap[x][y] == 1) {
                        this.tetrisMap[x][y] = 0
                        this.tetrisMap[x][y + 1] = 1
                    }
                }
            }
            // move objects down
            for (var i = 0; i < this.tetris_total_list.length; i++) {
                var e = this.tetris_total_list[i]
                if (e && e.y < ry) {
                    e.y += 1
                    e.obj.set_pos(e.x * BLOCK + OFF_X, e.y * BLOCK + OFF_Y)
                }
            }
        }

        var n = rows.length
        this.lines += n
        if (n == 1) this.game_score += SCORE_1LINE
        else if (n == 2) this.game_score += SCORE_2LINE
        else if (n == 3) this.game_score += SCORE_3LINE
        else if (n >= 4) this.game_score += SCORE_4LINE

        this.level = 1 + Math.floor(this.lines / 10)
        this.dropInterval = Math.max(8, 30 - (this.level - 1) * 4)

        if (this.game_score > this.high_score) this.high_score = this.game_score
        this._updateScoreLabel()
        return n
    }

    _spawnPiece() {
        this.tetrisShapeType = this.nextShapeType !== undefined ? this.nextShapeType : (Math.random() * 7) | 0
        this.nextShapeType = (Math.random() * 7) | 0
        this.pieceColor = (Math.random() * 3) | 0
        this.nextColor = (Math.random() * 3) | 0
        this.pieceX = 4
        this.pieceY = -1
        this.pieceRot = 1
        this.box_new = 1
        if (!this._canMove(0, 0, 1)) {
            this.screen = SCREEN_GAMEOVER
        }
        this._drawPiece()
        this._drawNextPreview()
    }

    _drawPiece() {
        // clear old visuals
        if (this.tetris_list) {
            for (var i = 0; i < this.tetris_list.length; i++) {
                if (this.tetris_list[i] && this.tetris_list[i].obj) {
                    this.tetris_list[i].obj.delete()
                }
            }
        }
        this.tetris_list = []
        var shape = this._cellShape()
        for (var i = 0; i < 4; i++) {
            var x = this.pieceX + shape[i][0]
            var y = this.pieceY + shape[i][1]
            if (y < 0) continue // off-screen top, still logical but not drawn
            var obj = new img(this.root())
            obj.set_src(this.path() + this.tetris_table[this.pieceColor])
            obj.set_pos(x * BLOCK + OFF_X, y * BLOCK + OFF_Y)
            this.tetris_list.push({obj: obj, x: x, y: y})
        }
    }

    _drawNextPreview() {
        if (!this.next_cont) return
        // clear old
        // (simple: recreate)
        var shape = SHAPES[this.nextShapeType][1]
        // placeholder - preview drawn as small blocks; kept minimal to control size
    }

    _updateScoreLabel() {
        if (this.obj_sroce) {
            this.obj_sroce.set_text(this.game_score.toString())
            this.obj_sroce.realign()
        }
    }

    refresh() {
        if (this.show_time) {
            var cur = new Date()
            if (cur.getMinutes() != this.last_min) {
                if (1 == lv.app_get_sys_hour_mode()) {
                    var h = cur.getHours() % 12
                    this.txt_time_hour.set_text(h.toString().padStart(2, "0"))
                    this.txt_time_hour.realign()
                } else {
                    this.txt_time_hour.set_text(cur.getHours().toString().padStart(2, "0"))
                }
                this.txt_time_min.set_text(cur.getMinutes().toString().padStart(2, "0"))
                this.last_min = cur.getMinutes()
            }
        }
        if (!this.gameStartFlag) return
        if (lv.app_get_screen_lock_state()) {
            lv.lvsf_gesture_disable()
            lv.app_disable_screen_lock_time()
        }
        this._gameLoop()
    }

    _gameLoop() {
        if (this.screen != SCREEN_PLAYING) return

        // auto-drop
        this.dropTimer++
        if (this.dropTimer >= this.dropInterval) {
            this.dropTimer = 0
            if (this._canMove(0, 1)) {
                this.pieceY++
                this._drawPiece()
            } else {
                this._lockPiece()
                if (this.screen == SCREEN_PLAYING) {
                    this._clearLines()
                    this._spawnPiece()
                }
            }
        }

        this._updateScoreLabel()
        this._showGameoverIfNeeded()
    }

    _showGameoverIfNeeded() {
        if (this.screen == SCREEN_GAMEOVER) {
            this.gameStartFlag = false
            lv.app_enable_screen_lock_time()
            lv.lvsf_gesture_enable()
            lv.game_tetris_set_score(this.game_score)
            this.result_bigbtn.set_hidden(false)
            this.result_bigbtn.move_foreground()
            this.result_btn.set_hidden(false)
            this.result_btn.move_foreground()
            this.gameover.set_hidden(false)
            this.gameover.move_foreground()
            this.txt_result.set_text(this.game_score.toString())
            this.txt_result.realign()
            this.gameagain.set_hidden(false)
            this.gameagain.set_click(true)
            this.gameagain.move_foreground()
            this.gameback.set_hidden(false)
            this.gameback.set_click(true)
            this.gameback.move_foreground()
            this.obj_bg.set_click(false)
        }
    }

    /*======================================================================
      CROWN / ROTARY INPUT
      The watch exposes crown ticks via lv input device events.
      We map CW rotation -> move right, CCW -> move left, crown click -> rotate.
      If the firmware API differs, swap the event checks below.
    ======================================================================*/
    _onCrownEvent(event, dir) {
        if (this.screen != SCREEN_PLAYING) return
        // dir: +1 clockwise, -1 counter-clockwise
        if (dir > 0) {
            if (this._canMove(1, 0)) { this.pieceX++; this._drawPiece() }
        } else if (dir < 0) {
            if (this._canMove(-1, 0)) { this.pieceX--; this._drawPiece() }
        }
        // crown press = rotate
        if (event == lv_enums.EVENT_SHORT_CLICKED) {
            var nr = this.pieceRot + 1
            if (nr > 4) nr = 1
            if (this._canMove(0, 0, nr)) { this.pieceRot = nr; this._drawPiece() }
        }
    }

    /*======================================================================
      TOUCH / GESTURE
    ======================================================================*/
    _onGesture(event) {
        if (this.screen == SCREEN_GAMEOVER) return
        var drag_dir = lv.indev_drag_dir_get()
        if (event == lv_enums.EVENT_PRESSING) {
            if (drag_dir && this.tetris_gesture == 0) {
                this.tetris_gesture = 1
                if (drag_dir & DIR_RIGHT) {
                    if (this._canMove(1, 0)) { this.pieceX++; this._drawPiece() }
                } else if (drag_dir & DIR_LEFT) {
                    if (this._canMove(-1, 0)) { this.pieceX--; this._drawPiece() }
                }
            }
        } else if (event == lv_enums.EVENT_RELEASED) {
            this.tetris_gesture = 0
        } else if (event == lv_enums.EVENT_SHORT_CLICKED && this.tetris_gesture == 0) {
            var nr = this.pieceRot + 1
            if (nr > 4) nr = 1
            if (this._canMove(0, 0, nr)) { this.pieceRot = nr; this._drawPiece() }
        }
    }

    /*======================================================================
      TITLE SCREEN
    ======================================================================*/
    _backToTitle() {
        // clear locked piece objects
        for (var i = 0; i < this.tetris_total_list.length; i++) {
            var e = this.tetris_total_list[i]
            if (e && e.obj) e.obj.delete()
        }
        this.tetris_total_list = []
        this._initMap()

        this.gameover.set_hidden(true)
        this.gameagain.set_click(false)
        this.gameagain.set_hidden(true)
        this.gameback.set_click(false)
        this.gameback.set_hidden(true)

        this.result_bigbtn.set_hidden(true)
        this.result_btn.set_hidden(true)
        this.obj_bg.set_hidden(true)
        this.obj_sroce.set_hidden(true)

        this.txt_title.set_hidden(false)
        this.show_time = true
        this.txt_time_dot.set_hidden(false)
        this.txt_time_hour.set_hidden(false)
        this.txt_time_min.set_hidden(false)

        this.icon.set_hidden(false)
        this.score_cont.set_width(60 + 20 + 22 * this.game_score.toString().length)
        this.score_cont.realign()
        this.score_cont.set_hidden(false)
        this.img_score.set_hidden(false)
        this.txt_score.set_text(this.game_score.toString())
        this.txt_score.realign()
        this.txt_score.set_hidden(false)

        this.img_start.set_click(true)
        this.img_start.set_hidden(false)

        this.last_min = -1
        this.refresh()
    }

    _restart() {
        for (var i = 0; i < this.tetris_total_list.length; i++) {
            var e = this.tetris_total_list[i]
            if (e && e.obj) e.obj.delete()
        }
        this.tetris_total_list = []
        this._initMap()

        this.game_score = 0
        this.level = 1
        this.lines = 0
        this.dropInterval = 30
        this._updateScoreLabel()

        this.screen = SCREEN_PLAYING
        this.gameStartFlag = true
        this.gameover.set_hidden(true)
        this.result_bigbtn.set_hidden(true)
        this.result_btn.set_hidden(true)
        this.gameback.set_hidden(true)
        this.gameback.set_click(false)
        this.gameagain.set_hidden(true)
        this.gameagain.set_click(false)

        this.obj_bg.set_click(true)
        this._spawnPiece()
    }

    /*======================================================================
      PLAYING SCREEN SETUP
    ======================================================================*/
    _enterGame() {
        var self = this
        this.show_time = false
        this.txt_title.set_hidden(true)
        this.txt_time_dot.set_hidden(true)
        this.txt_time_hour.set_hidden(true)
        this.txt_time_min.set_hidden(false)

        this.icon.set_hidden(true)
        this.score_cont.set_hidden(true)
        this.img_score.set_hidden(true)
        this.txt_score.set_hidden(true)

        this.img_start.set_click(false)
        this.img_start.set_hidden(true)

        this.gameStartFlag = true
        this.screen = SCREEN_PLAYING

        this._drawBg()

        this.game_score = 0
        this.level = 1
        this.lines = 0
        this.dropInterval = 30
        this._initMap()

        if (this.obj_sroce) {
            this.obj_sroce.set_local_font(lv_enums.FONT_BIGL, lv.color_make(0xFF, 0xFF, 0xFF))
            this.obj_sroce.set_text("0")
            this.obj_sroce.align(this.root(), lv_enums.ALIGN_IN_TOP_RIGHT, -50, 10)
            this.obj_sroce.set_hidden(false)
        }

        this._drawBgUI()
        this._spawnPiece()
    }

    _drawBg() {
        if (this.obj_bg) {
            this.obj_bg.set_pos(0, 0)
            this.obj_bg.set_src(this.path() + "bg.bin")
            this.obj_bg.set_click(true)
            this.obj_bg.set_hidden(false)
            this.obj_bg.set_event_cb(function (e) { /* handled via root cb */ })
        } else {
            this.obj_bg = new img(this.root())
            this.obj_bg.set_pos(0, 0)
            this.obj_bg.set_src(this.path() + "bg.bin")
            this.obj_bg.set_click(true)
            this.obj_bg.set_hidden(false)
        }
    }

    _drawBgUI() {
        var self = this
        this.obj_bg.set_event_cb(function (event) {
            self._onGesture(event)
            // crown events route here too if firmware sends them as gesture events
            self._onCrownEvent(event, 0)
        })
    }

    /*======================================================================
      GAME OVER SCREEN
    ======================================================================*/
    _setupGameOver() {
        var self = this

        this.result_bigbtn = new btn(this.root())
        this.result_bigbtn.reset_style_list(0)
        this.result_bigbtn.set_layout(0)
        this.result_bigbtn.set_size(this.LV_HOR_RES_MAX, this.LV_VER_RES_MAX)
        this.result_bigbtn.set_pos(0, 0)
        this.result_bigbtn.ext_set_local_radius(0, 0, 102)
        this.result_bigbtn.ext_set_local_bg(lv.color_make(0x00, 0x00, 0x00), 180)
        this.result_bigbtn.set_hidden(true)

        this.result_btn = new btn(this.result_bigbtn.nativeobj)
        this.result_btn.reset_style_list(0)
        this.result_btn.set_layout(0)
        this.result_btn.set_size(300, 60)
        this.result_btn.set_pos(25, 154)
        this.result_btn.ext_set_local_radius(0, 0, 30)
        this.result_btn.ext_set_local_bg(lv.color_make(0xFF, 0xFF, 0xFF), 60)

        this.result_cont = new cont(this.result_btn.nativeobj)
        this.result_cont.set_size(140, 40)
        this.result_cont.align(this.result_btn.nativeobj, lv_enums.ALIGN_CENTER, 0, 0)

        this.img_result = new img(this.result_cont.nativeobj)
        this.img_result.set_src(this.path() + "score.bin")
        this.img_result.align(this.result_cont.nativeobj, lv_enums.ALIGN_IN_LEFT_MID, 0, 0)

        this.txt_result = new label(this.result_cont.nativeobj)
        this.txt_result.set_local_font(lv_enums.FONT_BIGL, lv.color_make(0xFF, 0xFF, 0xFF))
        this.txt_result.set_text("0")
        this.txt_result.align(this.img_result.nativeobj, lv_enums.ALIGN_OUT_RIGHT_MID, 10, -4)
        this.result_btn.set_hidden(true)

        this.gameover = new img(this.root())
        this.gameover.set_src(this.path() + "game_over.bin")
        this.gameover.set_pos((this.LV_HOR_RES_MAX - this.gameover.get_width()) / 2, 74)
        this.gameover.set_hidden(true)

        this.gameagain = new img(this.root())
        this.gameagain.set_src(this.path() + "again.bin")
        this.gameagain.set_pos((this.LV_HOR_RES_MAX - this.gameagain.get_width()) / 2, 268)
        this.gameagain.set_hidden(true)
        this.gameagain.set_click(false)
        this.gameagain.set_event_cb(function (event) {
            if (event == lv_enums.EVENT_RELEASED) {
                self.gameagain.set_zoom(256)
                self._restart()
            } else if (event == lv_enums.EVENT_PRESSED) {
                self.gameagain.set_zoom(240)
            } else if (event == lv_enums.EVENT_PRESS_LOST) {
                self.gameagain.set_zoom(256)
            }
        })

        this.gameback = new img(this.root())
        this.gameback.set_src(this.path() + "back.bin")
        this.gameback.set_pos((this.LV_HOR_RES_MAX - this.gameback.get_width()) / 2, 339)
        this.gameback.set_hidden(true)
        this.gameback.set_click(false)
        this.gameback.set_event_cb(function (event) {
            if (event == lv_enums.EVENT_RELEASED) {
                self.gameback.set_zoom(256)
                self._backToTitle()
            } else if (event == lv_enums.EVENT_PRESSED) {
                self.gameback.set_zoom(240)
            } else if (event == lv_enums.EVENT_PRESS_LOST) {
                self.gameback.set_zoom(256)
            }
        })
    }

    /*======================================================================
      LIFECYCLE
    ======================================================================*/
    start() {
        lv.app_exit_jsapp_wait_screen()
        app_get_str("js_key_language", "language")
        app_get_str("js_key_qjs_detail", "An entertaining small game")

        this.game_score = lv.game_tetris_get_score()
        this.high_score = this.game_score

        var self = this
        this.txt_title = new label(this.root())
        this.txt_title.set_local_font(lv_enums.FONT_BIGL, lv.color_make(0xF9, 0xDB, 0x37))
        this.txt_title.set_text(app_get_str("js_key_qjs_name", "Tetris"))
        this.txt_title.set_long_mode(4)
        this.txt_title.set_width(228)
        this.txt_title.align(this.root(), lv_enums.ALIGN_IN_TOP_LEFT, 42, 15)

        // clock
        this.txt_time_dot = new label(this.root())
        this.txt_time_dot.set_text(":")
        this.txt_time_dot.set_local_font(lv_enums.FONT_BIGL, lv.color_make(0xFF, 0xFF, 0xFF))
        this.txt_time_dot.align(this.root(), lv_enums.ALIGN_IN_TOP_RIGHT, -85, 16)
        this.txt_time_dot.set_auto_realign(true)

        this.txt_time_hour = new label(this.root())
        this.txt_time_hour.set_local_font(lv_enums.FONT_BIGL, lv.color_make(0xFF, 0xFF, 0xFF))
        this.txt_time_hour.align(this.txt_time_dot.nativeobj, lv_enums.ALIGN_OUT_LEFT_MID, 0, 0)
        this.txt_time_hour.set_auto_realign(true)

        this.txt_time_min = new label(this.root())
        this.txt_time_min.set_local_font(lv_enums.FONT_BIGL, lv.color_make(0xFF, 0xFF, 0xFF))
        this.txt_time_min.align(this.txt_time_dot.nativeobj, lv_enums.ALIGN_OUT_RIGHT_MID, 0, 0)
        this.txt_time_min.set_auto_realign(true)

        this.icon = new img(this.root())
        this.icon.set_pos(110, 86)
        this.icon.set_src(this.path() + "icon.bin")

        this.score_cont = new cont(this.root())
        this.score_cont.set_size(60 + 20 + 22 * this.game_score.toString().length, 40)
        this.score_cont.align(this.root(), lv_enums.ALIGN_IN_TOP_MID, 0, 307)

        this.img_score = new img(this.score_cont.nativeobj)
        this.img_score.align(this.score_cont.nativeobj, lv_enums.ALIGN_IN_TOP_LEFT, 0, 0)
        this.img_score.set_src(this.path() + "score.bin")

        this.txt_score = new label(this.score_cont.nativeobj)
        this.txt_score.set_local_font(lv_enums.FONT_BIGL, lv.color_make(0xFF, 0xFF, 0xFF))
        this.txt_score.set_text(this.game_score.toString())
        this.txt_score.set_align(1)
        this.txt_score.set_width(80)
        this.txt_score.align(this.img_score.nativeobj, lv_enums.ALIGN_OUT_RIGHT_MID, 20, -4)

        this.obj_sroce = new label(this.root())
        this.obj_sroce.set_local_font(lv_enums.FONT_BIGL, lv.color_make(0xFF, 0xFF, 0xFF))
        this.obj_sroce.set_text("0")
        this.obj_sroce.set_hidden(true)

        this.img_start = new img(this.root())
        this.img_start.set_pos(48, 382)
        this.img_start.set_src(this.path() + "start.bin")
        this.img_start.set_click(true)
        this.img_start.set_event_cb(function (event) {
            if (event == lv_enums.EVENT_RELEASED) {
                self.img_start.set_zoom(256)
                self._enterGame()
            } else if (event == lv_enums.EVENT_PRESSED) {
                self.img_start.set_zoom(240)
            } else if (event == lv_enums.EVENT_PRESS_LOST) {
                self.img_start.set_zoom(256)
            }
        })

        this._setupGameOver()

        this.last_min = -1
        this.refresh()
    }

    pause() {
        this.gameStartFlag = false
        lv.app_enable_screen_lock_time()
        lv.lvsf_gesture_enable()
    }

    resume() {
        this.refresh()
    }

    stop() {
        var obs = [this.gameagain, this.gameback, this.img_start, this.obj_bg]
        for (var i = 0; i < obs.length; i++) {
            var o = obs[i]
            if (o) { o.set_click(false); o.set_event_cb(null) }
        }
    }
}

globalThis.JA_app_g00032 = JA_app_g00032
